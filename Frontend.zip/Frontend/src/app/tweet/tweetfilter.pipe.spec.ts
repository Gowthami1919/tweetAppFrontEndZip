import { TweetfilterPipe } from './tweetfilter.pipe';

describe('TweetfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TweetfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
