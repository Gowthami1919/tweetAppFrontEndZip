export class Register {
    constructor(
      public Firstname?: string,
      public Lastname?: string,
      public Gender?: string,
      public Dob?: string,
      public EmailId?: string,
      public Password?: string,
      
    ) {}
  }